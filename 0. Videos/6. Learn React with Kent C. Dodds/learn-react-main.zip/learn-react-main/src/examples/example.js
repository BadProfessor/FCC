import React from 'react'

export default () => (
  <p>
    any file you create in this directory will be accessible at{' '}
    <code>/examples/file-name</code>
  </p>
)
